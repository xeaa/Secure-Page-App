
from odoo import http
from odoo.http import request

class SecurePageController(http.Controller):

    @http.route('/secure_page/<int:page_id>', type='http', auth='public', website=True)
    def secure_page(self, page_id, access_code=None, **kwargs):
        # Abrufen der Seite
        page = request.env['secure.page'].sudo().browse(page_id)
        if not page.exists() or not page.is_active:
            return request.not_found()

        # Zugangscode validieren
        if access_code == page.access_code:
            # Zugangscode korrekt -> Seite anzeigen
            return request.render('secure_page_app_v2.page_template', {'page': page})
        else:
            # Zugangscode ungültig -> Zugang verweigert anzeigen
            return request.render('secure_page_app_v2.access_denied', {'page': page})
