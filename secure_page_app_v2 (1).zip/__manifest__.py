
{
    'name': 'Secure Page App v2',
    'version': '1.0',
    'author': 'Dein Name',
    'category': 'Website',
    'summary': 'Erstellt individuelle Seiten mit Zugangscode',
    'depends': ['website'],
    'data': [
        'views/templates.xml',
    ],
    'installable': True,
    'application': True,
    'license': 'LGPL-3',
}
