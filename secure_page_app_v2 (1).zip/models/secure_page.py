
from odoo import models, fields

class SecurePage(models.Model):
    _name = 'secure.page'
    _description = 'Secure Page Configuration'

    name = fields.Char(string="Page Name", required=True)
    access_code = fields.Char(string="Access Code", required=True)
    content = fields.Html(string="Page Content", required=True)
    is_active = fields.Boolean(string="Is Active", default=True)
